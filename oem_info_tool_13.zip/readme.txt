OEM Info Tool for Windows Vista/7/8
Version 1.3
Copyright (c) 2009-2013, www.TrishTech.com. All rights reserved.

OEM Info Tool is Freeware.


Introduction
------------
OEM Info Tool for Windows Vista/7/8 is a tool to edit/change the OEM information visible in the system properties window.


Requirements
------------
Windows Vista/7/8 both 32-bit and 64-bit editions.


Install/Uninstall
------------------
Installation or uninstallation is not required.


DISCLAIMER
----------
OEM Info Tool comes with ABSOLUTELY NO WARRANTY of any kind, whether express or implied. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL www.TrishTech.com OR ITS STAFF BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE PRODUCT, EVEN IF www.TrishTech.com HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.